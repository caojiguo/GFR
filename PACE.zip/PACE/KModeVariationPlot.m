%function KModeVariationPlot(yy)
%This function creates the k-th mode of variation plot based on the
%results from FPCA() or FPCder().
%Input yy : returned object from FPCA() or FPCder().
%Input k  : a positive integer (<= no_opt from FPCA(), or FPCder()) 
%           that specifies the k-th mode of variation plot that is 
%           of interest 
%           k can also be a row vector for multiple plots.
%           If missing, then, k = 1:no_opt
%example:
% yy = FPCA(y,t,p);
% KModeVariationPlot(yy)  %k-th mode variation plots for all k from 1 to no_opt
% or 
% p = setDerOptions('nder',0:2);
% yy = FPCder(y,t,p);
% KModeVariationPlot(yy,1) %k-th mode variation plot for k = 1
function KModeVariationPlot(yy, k)
  no_opt = getVal(yy,'no_opt');
  if nargin < 2 
    k = 1:no_opt;
  elseif any(k <= 0)
    fprintf(1,'Error: k must be a positive integer!\n');
    no_opt = [];
    return; 
  elseif any(k > no_opt)
    fprintf(1,['Error: any k cannot be larger than no_opt = ' num2str(no_opt) '\n']);
    no_opt = [];
    return;
  end

  lambda = getVal(yy,'lambda');
  mu = getVal(yy,'mu');
  if iscell(mu)
    mu = mu{1};
  end
  out1 = getVal(yy,'out1');
  phi = getVal(yy,'phi');
  if iscell(phi)
    phi = phi{1};
  end
   for i = 1:length(k)
     figure;
     alpha1 =0*sqrt(lambda(k(i)));
     tmp1 = alpha1*phi(:,k(i))';
       plot(out1, tmp1,'--');
       hold on; 
       alpha2 =sqrt(lambda(k(i)));
       tmp2 = alpha2*phi(:,k(i))';
       plot(out1, tmp2);
     end
     xlabel('t');
     ylabel(['\phi_' num2str(k(i)) '(t)']);
     axis([1,10, -10, 22]);
     title(['']);
     legend('off')
  end 

end

